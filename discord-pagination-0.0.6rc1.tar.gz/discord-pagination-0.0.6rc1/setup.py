from setuptools import setup, find_packages

version = "0.0.6-pre1"

with open("README.md", "r") as f:
	long_desc = f.read()

setup(
name="discord-pagination",
author="Alex Hutz",
version=version,
packages=find_packages(),
license='MIT',
long_description=long_desc,
long_description_content_type="text/markdown",
description="An package for discord pagination.",
python_requires='>=3.8.1'
)